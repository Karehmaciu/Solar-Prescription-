# VeraSol Product Matching Integration

## What's New

Your Solar Prescription app now shows **VeraSol certified products** that will work in the user's specific location!

## How It Works

1. **User fills form** → Location, kit size, appliances
2. **App calculates needs** → Daily energy requirement (Wh)
3. **App gets location data** → NREL PVWatts for solar production
4. **NEW: Product matching** → Finds VeraSol certified products that work 85%+ year-round
5. **Results page** → Shows prescription + matching certified products

## Key Features

### Smart Filtering
- Only shows products that meet **85% or more** of needs in worst month
- Filters by number of lights needed
- Accounts for 20% system losses
- Uses actual worst-month production for that location

### Visual Product Cards
Products are categorized and color-coded:
- **⭐ Excellent** (120%+ coverage) - Green
- **✓ Good** (100-120% coverage) - Blue  
- **✓ Adequate** (85-100% coverage) - Yellow

### What Users See
Each product card shows:
- Brand and model
- Solar panel wattage
- Number of light points
- Battery type
- Coverage percentage (worst month)
- Actual production in their location

## Files Added/Modified

### New Files
- `verasol_matcher.py` - Product matching logic
- `data/all_solar_kits_combined.csv` - VeraSol database (183 certified products)

### Modified Files
- `app.py` - Added VeraSol matcher integration
- `templates/results.html` - Added certified products section
- `static/css/styles.css` - Added product card styling

## Database

**Source:** VeraSol Product Database  
**Products:** 183 certified solar kits  
**Brands:** 62 manufacturers  
**Range:** 0.3W to 160W systems

All products meet:
- Lighting Global Quality Standards for pico-PV, OR
- Solar Home System Kit Quality Standards, OR
- IEC TS 62257-9-8 quality standards

## Example Flow

**User Input:**
- Location: Embu, Kenya
- Kit size considering: 10W
- Needs: 2 LED lights, 1 phone charger

**App Calculates:**
- Daily need: 40 Wh
- Worst month production per watt: 2.5 Wh/W/day
- Minimum kit needed: 16W (for 85% reliability)

**VeraSol Matcher Finds:**
1. StarTimes S50C (14W) - ⚠ Marginal, 76% coverage
2. Zimpertec PS-114 (9.3W) - ❌ Too small
3. **Recommended:** 20W+ kits for reliable operation

## Technical Details

### Matching Algorithm

```python
# Calculate minimum size needed
min_watts = (daily_need * 1.2) / (worst_month_wh_per_watt * 0.8)

# Filter products
matches = products[
    (pv_watts >= min_watts) &
    (light_points >= lights_needed)
]

# Calculate coverage for each
coverage = (product_watts * worst_month_per_watt * 0.8) / daily_need * 100
```

### Coverage Categories
- **Excellent:** 120%+ (comfortable margin)
- **Good:** 100-120% (meets needs)
- **Adequate:** 85-100% (acceptable)
- **Marginal:** <85% (not shown by default)

## Updating the Database

To update with new VeraSol products:

1. Download latest data from https://data.verasol.org/
2. Export as CSV
3. Replace `data/all_solar_kits_combined.csv`
4. Restart the app

The matcher will automatically load the new data.

## Future Enhancements

Possible additions:
1. **Appliance capability matching** - Does product support TV? Fan?
2. **Price comparison** - If pricing data available
3. **Availability by region** - Filter by where products are sold
4. **User reviews/ratings** - If available
5. **Direct purchase links** - Link to distributors

## Testing

To test the integration:

```bash
cd solar_prescription
python app.py
```

Visit http://localhost:5000

Try different locations and appliances to see how product recommendations change!

## Notes

- Products with "Modular" or "Family" in model number are filtered out (configurable families, not specific products)
- Products with 0W or N/A wattage are filtered out
- Only top 6 matching products shown on results page
- Database includes products from major brands like Sun King, d.light, Solar Run, Bboxx, etc.

## Contact

Integration by: Maina  
Part of: Solar Prescription Initiative  
Goal: Consumer protection through transparency
