// Solar Prescription - Frontend JavaScript

// Common African cities for quick location lookup
const COMMON_LOCATIONS = {
    'nairobi': { lat: -1.2921, lon: 36.8219, name: 'Nairobi, Kenya' },
    'mombasa': { lat: -4.0435, lon: 39.6682, name: 'Mombasa, Kenya' },
    'kisumu': { lat: -0.0917, lon: 34.7680, name: 'Kisumu, Kenya' },
    'kampala': { lat: 0.3476, lon: 32.5825, name: 'Kampala, Uganda' },
    'dar es salaam': { lat: -6.7924, lon: 39.2083, name: 'Dar es Salaam, Tanzania' },
    'kigali': { lat: -1.9706, lon: 30.1044, name: 'Kigali, Rwanda' },
    'addis ababa': { lat: 9.0320, lon: 38.7469, name: 'Addis Ababa, Ethiopia' },
    'lagos': { lat: 6.5244, lon: 3.3792, name: 'Lagos, Nigeria' },
    'accra': { lat: 5.6037, lon: -0.1870, name: 'Accra, Ghana' },
    'johannesburg': { lat: -26.2041, lon: 28.0473, name: 'Johannesburg, South Africa' },
    'cape town': { lat: -33.9249, lon: 18.4241, name: 'Cape Town, South Africa' },
    'harare': { lat: -17.8252, lon: 31.0335, name: 'Harare, Zimbabwe' },
    'lusaka': { lat: -15.4167, lon: 28.2833, name: 'Lusaka, Zambia' },
    'maputo': { lat: -25.9655, lon: 32.5832, name: 'Maputo, Mozambique' },
    'windhoek': { lat: -22.5609, lon: 17.0658, name: 'Windhoek, Namibia' },
    'gaborone': { lat: -24.6282, lon: 25.9231, name: 'Gaborone, Botswana' },
    'dakar': { lat: 14.7167, lon: -17.4677, name: 'Dakar, Senegal' },
    'abidjan': { lat: 5.3600, lon: -4.0083, name: 'Abidjan, Ivory Coast' },
    'bamako': { lat: 12.6392, lon: -8.0029, name: 'Bamako, Mali' },
    'conakry': { lat: 9.6412, lon: -13.5784, name: 'Conakry, Guinea' },
};

// Location autocomplete
document.addEventListener('DOMContentLoaded', function() {
    const locationInput = document.getElementById('locationSearch');
    const suggestionsDiv = document.getElementById('locationSuggestions');
    const coordsDisplay = document.getElementById('coordinatesDisplay');
    const latInput = document.getElementById('latitude');
    const lonInput = document.getElementById('longitude');
    const locationNameInput = document.getElementById('locationName');
    
    // Show quantity inputs when appliance is selected
    const applianceCheckboxes = document.querySelectorAll('input[name="appliance"]');
    applianceCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const qtyInputId = this.dataset.qtyInput;
            const qtyInput = document.getElementById(qtyInputId);
            if (this.checked) {
                qtyInput.style.display = 'block';
            } else {
                qtyInput.style.display = 'none';
            }
        });
    });
    
    // Location search
    if (locationInput) {
        locationInput.addEventListener('input', function() {
            const query = this.value.toLowerCase().trim();
            
            if (query.length < 2) {
                suggestionsDiv.innerHTML = '';
                return;
            }
            
            // Filter matching locations
            const matches = Object.entries(COMMON_LOCATIONS)
                .filter(([key, data]) => key.includes(query) || data.name.toLowerCase().includes(query))
                .slice(0, 5);
            
            if (matches.length > 0) {
                suggestionsDiv.innerHTML = matches.map(([key, data]) => 
                    `<div class="location-suggestion" data-lat="${data.lat}" data-lon="${data.lon}" data-name="${data.name}">
                        ${data.name}
                    </div>`
                ).join('');
                
                // Add click handlers
                suggestionsDiv.querySelectorAll('.location-suggestion').forEach(item => {
                    item.addEventListener('click', function() {
                        const lat = this.dataset.lat;
                        const lon = this.dataset.lon;
                        const name = this.dataset.name;
                        
                        locationInput.value = name;
                        latInput.value = lat;
                        lonInput.value = lon;
                        locationNameInput.value = name;
                        
                        coordsDisplay.style.display = 'block';
                        document.getElementById('coordsText').textContent = `${lat}, ${lon}`;
                        
                        suggestionsDiv.innerHTML = '';
                    });
                });
            } else {
                suggestionsDiv.innerHTML = '<div class="location-suggestion">No matching locations found. Try: Nairobi, Lagos, or Johannesburg</div>';
            }
        });
        
        // Close suggestions when clicking outside
        document.addEventListener('click', function(e) {
            if (!locationInput.contains(e.target) && !suggestionsDiv.contains(e.target)) {
                suggestionsDiv.innerHTML = '';
            }
        });
    }
    
    // Form submission
    const form = document.getElementById('prescriptionForm');
    if (form) {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Validate location is selected
            if (!latInput.value || !lonInput.value) {
                alert('Please select a location from the suggestions');
                return;
            }
            
            // Get selected kit size
            const kitSize = document.querySelector('input[name="kitSize"]:checked');
            if (!kitSize) {
                alert('Please select a kit size');
                return;
            }
            
            // Get selected appliances
            const appliances = [];
            applianceCheckboxes.forEach(checkbox => {
                if (checkbox.checked) {
                    const qtyInputId = checkbox.dataset.qtyInput;
                    const quantity = parseInt(document.getElementById(qtyInputId).value) || 1;
                    appliances.push({
                        id: checkbox.value,
                        quantity: quantity
                    });
                }
            });
            
            if (appliances.length === 0) {
                alert('Please select at least one appliance');
                return;
            }
            
            // Prepare data
            const formData = {
                location: locationNameInput.value,
                latitude: parseFloat(latInput.value),
                longitude: parseFloat(lonInput.value),
                kit_size: parseInt(kitSize.value),
                appliances: appliances
            };
            
            // Show loading
            document.getElementById('loadingSpinner').style.display = 'block';
            document.getElementById('submitBtn').disabled = true;
            document.getElementById('errorMessage').style.display = 'none';
            
            try {
                const response = await fetch('/prescribe', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    // Redirect to results page
                    window.location.href = '/results';
                } else {
                    throw new Error(result.error || 'An error occurred');
                }
            } catch (error) {
                document.getElementById('errorMessage').textContent = error.message;
                document.getElementById('errorMessage').style.display = 'block';
                document.getElementById('submitBtn').disabled = false;
            } finally {
                document.getElementById('loadingSpinner').style.display = 'none';
            }
        });
    }
});
