"""
VeraSol Product Matcher
Matches user needs with certified VeraSol products that will work in their location
"""

import pandas as pd
import os

class VeraSolMatcher:
    """
    Matches energy needs with VeraSol certified products
    """
    
    def __init__(self, csv_path='data/all_solar_kits_combined.csv'):
        """Load VeraSol database"""
        self.csv_path = csv_path
        self.products = None
        self.load_database()
    
    def load_database(self):
        """Load and clean the VeraSol product database"""
        try:
            df = pd.read_csv(self.csv_path)
            
            # Clean up data
            # Convert PV Module Maximum Power to numeric, handle N/A
            df['PV_Watts'] = pd.to_numeric(
                df['PV Module Maximum Power [W]'].replace('N/A', 0), 
                errors='coerce'
            ).fillna(0)
            
            # Convert Number of Light Points to numeric
            df['Light_Points'] = pd.to_numeric(
                df['Number of Light Points'].replace('N/A', 0), 
                errors='coerce'
            ).fillna(0)
            
            # Filter out modular/family entries and 0W entries
            df = df[
                (df['PV_Watts'] > 0) & 
                (~df['Model Number'].str.contains('Modular', na=False))
            ]
            
            self.products = df
            return True
            
        except Exception as e:
            print(f"Error loading VeraSol database: {e}")
            self.products = pd.DataFrame()
            return False
    
    def find_matching_products(
        self, 
        daily_need_wh, 
        worst_month_irradiance_wh_per_watt,
        min_lights=0,
        target_reliability=0.85
    ):
        """
        Find products that will meet needs with target reliability
        
        Args:
            daily_need_wh: Daily energy need in Wh
            worst_month_irradiance_wh_per_watt: Worst month production per watt
            min_lights: Minimum number of light points needed
            target_reliability: Target coverage (0.85 = 85%)
        
        Returns:
            List of matching products with coverage analysis
        """
        if self.products is None or len(self.products) == 0:
            return []
        
        # Calculate minimum kit size needed
        # Account for 20% system losses
        min_kit_watts = (daily_need_wh * 1.2) / (worst_month_irradiance_wh_per_watt * 0.8)
        
        # Filter products
        matches = self.products[
            (self.products['PV_Watts'] >= min_kit_watts) &
            (self.products['Light_Points'] >= min_lights)
        ].copy()
        
        if len(matches) == 0:
            return []
        
        # Calculate coverage for each product
        matches['worst_month_production'] = matches['PV_Watts'] * worst_month_irradiance_wh_per_watt * 0.8
        matches['coverage_percent'] = (matches['worst_month_production'] / daily_need_wh * 100).round(1)
        
        # Categorize products
        matches['category'] = matches['coverage_percent'].apply(self._categorize_product)
        
        # Sort by coverage (best first) then by wattage (smallest adequate first)
        matches = matches.sort_values(['coverage_percent', 'PV_Watts'], ascending=[False, True])
        
        # Convert to list of dicts
        results = []
        for _, row in matches.head(10).iterrows():  # Return top 10 matches
            results.append({
                'brand': row['Brand'],
                'product_name': row['Product Name'],
                'model': row['Model Number'],
                'pv_watts': int(row['PV_Watts']),
                'light_points': int(row['Light_Points']),
                'battery_type': row['Main Unit Battery Chemistry'],
                'worst_month_coverage': row['coverage_percent'],
                'category': row['category'],
                'worst_month_production': round(row['worst_month_production'], 0)
            })
        
        return results
    
    def _categorize_product(self, coverage_percent):
        """Categorize product based on coverage"""
        if coverage_percent >= 120:
            return 'excellent'
        elif coverage_percent >= 100:
            return 'good'
        elif coverage_percent >= 85:
            return 'adequate'
        else:
            return 'marginal'
    
    def get_product_stats(self):
        """Get database statistics"""
        if self.products is None or len(self.products) == 0:
            return {
                'total_products': 0,
                'brands': 0,
                'size_range': '0-0W'
            }
        
        return {
            'total_products': len(self.products),
            'brands': self.products['Brand'].nunique(),
            'size_range': f"{self.products['PV_Watts'].min():.0f}-{self.products['PV_Watts'].max():.0f}W"
        }
