"""
Solar Prescription Engine
Core logic for determining if a solar kit is suitable for a location and usage pattern
"""

class SolarPrescription:
    """
    Generates solar kit prescriptions based on location, kit size, and energy needs
    """
    
    # Typical appliance power consumption (Watts)
    APPLIANCE_SPECS = {
        'led_bulb': {'watts': 10, 'hours': 5, 'label': 'LED Bulb (10W)'},
        'phone_charger': {'watts': 10, 'hours': 2, 'label': 'Phone Charger'},
        'laptop': {'watts': 65, 'hours': 4, 'label': 'Laptop'},
        'small_tv': {'watts': 50, 'hours': 4, 'label': 'Small TV (24")'},
        'large_tv': {'watts': 150, 'hours': 4, 'label': 'Large TV (42")'},
        'fan': {'watts': 75, 'hours': 8, 'label': 'Fan'},
        'radio': {'watts': 10, 'hours': 3, 'label': 'Radio'},
        'wifi_router': {'watts': 10, 'hours': 24, 'label': 'WiFi Router'},
        'small_fridge': {'watts': 100, 'hours': 24, 'label': 'Small Fridge (DC)'},
        'laptop_charger': {'watts': 45, 'hours': 3, 'label': 'Laptop Charger'},
        'decoder': {'watts': 15, 'hours': 4, 'label': 'TV Decoder'},
        'security_lights': {'watts': 20, 'hours': 12, 'label': 'Security Lights'},
    }
    
    # Kit sizes we support (in Watts)
    KIT_SIZES = [50, 100, 150, 200, 300, 500, 1000]
    
    def __init__(self):
        self.prescription = {}
    
    def calculate_daily_energy_need(self, appliances):
        """
        Calculate total daily energy requirement from selected appliances
        Returns: Daily energy need in Wh
        """
        total_wh = 0
        appliance_details = []
        
        for app in appliances:
            app_id = app.get('id')
            quantity = app.get('quantity', 1)
            
            if app_id in self.APPLIANCE_SPECS:
                spec = self.APPLIANCE_SPECS[app_id]
                daily_wh = spec['watts'] * spec['hours'] * quantity
                total_wh += daily_wh
                
                appliance_details.append({
                    'name': spec['label'],
                    'quantity': quantity,
                    'watts': spec['watts'],
                    'hours': spec['hours'],
                    'daily_wh': daily_wh
                })
        
        return total_wh, appliance_details
    
    def get_daily_production(self, pvwatts_data, kit_size):
        """
        Extract daily production from PVWatts data
        Returns: Average daily production in Wh, monthly breakdown
        """
        outputs = pvwatts_data.get('outputs', {})
        annual_kwh = outputs.get('ac_annual', 0)
        monthly_kwh = outputs.get('ac_monthly', [])
        
        # Convert to Wh
        annual_wh = annual_kwh * 1000
        daily_avg_wh = annual_wh / 365
        
        # Find best and worst months
        monthly_wh = [m * 1000 for m in monthly_kwh]
        best_month_wh = max(monthly_wh) / 30 if monthly_wh else 0
        worst_month_wh = min(monthly_wh) / 30 if monthly_wh else 0
        
        return {
            'daily_avg': daily_avg_wh,
            'best_month_daily': best_month_wh,
            'worst_month_daily': worst_month_wh,
            'annual_total': annual_wh,
            'monthly': monthly_wh
        }
    
    def determine_verdict(self, production, need):
        """
        Determine if kit is suitable
        Returns: verdict ('excellent', 'good', 'marginal', 'insufficient')
        """
        # Account for system losses (inverter, battery, wiring = 20% total)
        usable_production = production['daily_avg'] * 0.8
        worst_month_usable = production['worst_month_daily'] * 0.8
        
        # Calculate coverage ratios
        avg_coverage = (usable_production / need * 100) if need > 0 else 0
        worst_coverage = (worst_month_usable / need * 100) if need > 0 else 0
        
        # Determine verdict
        if avg_coverage >= 120:
            verdict = 'excellent'
        elif avg_coverage >= 100 and worst_coverage >= 80:
            verdict = 'good'
        elif avg_coverage >= 80 or worst_coverage >= 60:
            verdict = 'marginal'
        else:
            verdict = 'insufficient'
        
        return {
            'verdict': verdict,
            'avg_coverage': round(avg_coverage, 1),
            'worst_coverage': round(worst_coverage, 1),
            'usable_daily': round(usable_production, 0),
            'worst_month_usable': round(worst_month_usable, 0)
        }
    
    def get_recommendation(self, verdict_info, need, kit_size, production):
        """
        Generate human-readable recommendation
        """
        verdict = verdict_info['verdict']
        
        if verdict == 'excellent':
            return {
                'status': 'approved',
                'title': '✓ This Kit Will Work Perfectly',
                'message': f'This {kit_size}W kit produces more than enough energy for your needs. You have a comfortable safety margin even during cloudy days.',
                'confidence': 'high',
                'warnings': []
            }
        
        elif verdict == 'good':
            return {
                'status': 'approved',
                'title': '✓ This Kit Will Work',
                'message': f'This {kit_size}W kit meets your daily energy needs. Expect reliable performance year-round.',
                'confidence': 'high',
                'warnings': ['Consider reducing usage slightly during the worst month (typically rainy season)']
            }
        
        elif verdict == 'marginal':
            warnings = [
                f'You\'ll get only {verdict_info["worst_coverage"]}% of your needs in the worst month',
                'Plan to reduce usage during rainy/cloudy periods',
                'Consider upgrading to the next kit size for better reliability'
            ]
            
            # Suggest next size up
            next_size = self._get_next_kit_size(kit_size)
            
            return {
                'status': 'warning',
                'title': '⚠ This Kit is Marginal',
                'message': f'This {kit_size}W kit will work most of the year, but you\'ll face shortages during low-sun months.',
                'confidence': 'medium',
                'warnings': warnings,
                'suggestion': f'We recommend upgrading to a {next_size}W kit for year-round reliability'
            }
        
        else:  # insufficient
            # Calculate needed size
            needed_size = self._calculate_needed_size(need, production['daily_avg'], kit_size)
            
            return {
                'status': 'rejected',
                'title': '✗ This Kit is Too Small',
                'message': f'This {kit_size}W kit cannot meet your energy needs. You need a larger system.',
                'confidence': 'high',
                'warnings': [
                    f'This kit only provides {verdict_info["avg_coverage"]}% of your daily needs',
                    'You will experience frequent power shortages',
                    'Batteries will discharge completely, reducing their lifespan'
                ],
                'suggestion': f'Minimum recommended: {needed_size}W kit'
            }
    
    def _get_next_kit_size(self, current_size):
        """Get the next available kit size"""
        for size in self.KIT_SIZES:
            if size > current_size:
                return size
        return current_size * 1.5  # If no standard size, suggest 50% more
    
    def _calculate_needed_size(self, need, production_per_watt, current_kit):
        """Calculate what kit size is actually needed"""
        # How much does current kit produce per watt?
        production_ratio = production_per_watt / current_kit
        
        # What size do we need for the required energy (with 20% margin)?
        needed_watts = (need * 1.2) / (production_ratio * 0.8)  # 0.8 for losses
        
        # Round up to next standard size
        for size in self.KIT_SIZES:
            if size >= needed_watts:
                return size
        
        # If larger than our standard sizes, round to nearest 100W
        return int((needed_watts + 99) // 100 * 100)
    
    def generate_prescription(self, location, latitude, longitude, kit_size, appliances, pvwatts_data):
        """
        Main method to generate complete prescription
        """
        # Calculate energy need
        daily_need, appliance_details = self.calculate_daily_energy_need(appliances)
        
        # Get production data
        production = self.get_daily_production(pvwatts_data, kit_size)
        
        # Determine verdict
        verdict_info = self.determine_verdict(production, daily_need)
        
        # Get recommendation
        recommendation = self.get_recommendation(verdict_info, daily_need, kit_size, production)
        
        # Get irradiance warnings based on location
        irradiance_warnings = self._get_irradiance_warnings(latitude, production)
        
        # Compile complete prescription
        prescription = {
            'location': {
                'name': location,
                'latitude': round(latitude, 4),
                'longitude': round(longitude, 4)
            },
            'kit_size': kit_size,
            'energy_need': {
                'daily_wh': round(daily_need, 0),
                'appliances': appliance_details
            },
            'production': {
                'daily_avg': round(production['daily_avg'], 0),
                'best_month': round(production['best_month_daily'], 0),
                'worst_month': round(production['worst_month_daily'], 0),
                'annual_kwh': round(production['annual_total'] / 1000, 0)
            },
            'verdict': verdict_info,
            'recommendation': recommendation,
            'irradiance_warnings': irradiance_warnings,
            'timestamp': datetime.now().isoformat()
        }
        
        return prescription
    
    def _get_irradiance_warnings(self, latitude, production):
        """
        Generate location-specific warnings based on irradiance
        """
        warnings = []
        
        # Low irradiance regions (far from equator, or low production)
        if abs(latitude) > 40:
            warnings.append({
                'level': 'high',
                'message': 'Your location receives significantly less sun than equatorial regions. Solar kit performance will be notably lower than advertised.'
            })
        elif abs(latitude) > 25:
            warnings.append({
                'level': 'medium',
                'message': 'Your location has moderate seasonal variation in solar production. Winter months will see reduced performance.'
            })
        
        # Check actual production variance
        variance = ((production['best_month_daily'] - production['worst_month_daily']) / 
                   production['best_month_daily'] * 100) if production['best_month_daily'] > 0 else 0
        
        if variance > 40:
            warnings.append({
                'level': 'high',
                'message': f'High seasonal variation: Production drops {variance:.0f}% in worst month. Plan accordingly.'
            })
        elif variance > 25:
            warnings.append({
                'level': 'medium',
                'message': f'Moderate seasonal variation: Expect {variance:.0f}% less production in rainy season.'
            })
        
        return warnings


from datetime import datetime
