from flask import Flask, render_template, request, jsonify, session, redirect
import os
from datetime import datetime
from prescription_engine import SolarPrescription
from pvwatts import get_pvwatts_data
from verasol_matcher import VeraSolMatcher
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Initialize VeraSol matcher
verasol_matcher = VeraSolMatcher()

@app.route('/')
def index():
    """Main landing page"""
    return render_template('index.html')

@app.route('/prescribe', methods=['POST'])
def prescribe():
    """Main prescription endpoint"""
    try:
        data = request.json
        
        # Extract user inputs
        location = data.get('location')
        latitude = float(data.get('latitude'))
        longitude = float(data.get('longitude'))
        kit_size = int(data.get('kit_size'))
        appliances = data.get('appliances', [])
        
        # Initialize prescription engine
        engine = SolarPrescription()
        
        # Get PVWatts data for this location
        # Convert kit size to kW (kit is in Watts)
        system_capacity_kw = kit_size / 1000
        
        pvwatts_data, error = get_pvwatts_data(
            system_capacity=system_capacity_kw,
            module_type=0,  # Standard
            array_type=1,   # Fixed - Roof Mounted
            tilt=abs(latitude),  # Use latitude as tilt
            azimuth=180 if latitude >= 0 else 0,  # South in N hemisphere
            lat=latitude,
            lon=longitude,
            losses=14  # Default losses
        )
        
        if error or not pvwatts_data:
            return jsonify({
                'success': False,
                'error': 'Could not fetch solar data for this location. Please try again.'
            }), 400
        
        # Calculate prescription
        prescription = engine.generate_prescription(
            location=location,
            latitude=latitude,
            longitude=longitude,
            kit_size=kit_size,
            appliances=appliances,
            pvwatts_data=pvwatts_data
        )
        
        # Find matching VeraSol products
        # Calculate worst month production per watt for matching
        outputs = pvwatts_data.get('outputs', {})
        monthly_kwh = outputs.get('ac_monthly', [])
        if monthly_kwh:
            worst_month_kwh = min(monthly_kwh)
            worst_month_wh_per_watt = (worst_month_kwh * 1000) / (kit_size * 30)  # Daily per watt
        else:
            worst_month_wh_per_watt = 0
        
        # Count lights needed
        lights_needed = sum(
            app.get('quantity', 1) 
            for app in appliances 
            if app.get('id') == 'led_bulb'
        )
        
        matching_products = verasol_matcher.find_matching_products(
            daily_need_wh=prescription['energy_need']['daily_wh'],
            worst_month_irradiance_wh_per_watt=worst_month_wh_per_watt,
            min_lights=lights_needed,
            target_reliability=0.85
        )
        
        # Add products to prescription
        prescription['matching_products'] = matching_products
        prescription['verasol_stats'] = verasol_matcher.get_product_stats()
        
        # Store in session for results page
        session['prescription'] = prescription
        session['location'] = location
        
        return jsonify({
            'success': True,
            'prescription': prescription
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/results')
def results():
    """Results page showing prescription details"""
    prescription = session.get('prescription')
    location = session.get('location')
    
    if not prescription:
        return redirect('/')
    
    return render_template('results.html', 
                         prescription=prescription,
                         location=location)

@app.route('/api/geocode')
def geocode():
    """Simple geocoding endpoint (you can enhance this with a geocoding API)"""
    # This is a placeholder - in production, use a geocoding API
    # For now, return some common locations
    query = request.args.get('q', '').lower()
    
    locations = {
        'nairobi': {'lat': -1.2921, 'lon': 36.8219},
        'mombasa': {'lat': -4.0435, 'lon': 39.6682},
        'kisumu': {'lat': -0.0917, 'lon': 34.7680},
        'kampala': {'lat': 0.3476, 'lon': 32.5825},
        'dar es salaam': {'lat': -6.7924, 'lon': 39.2083},
        'kigali': {'lat': -1.9706, 'lon': 30.1044},
        'addis ababa': {'lat': 9.0320, 'lon': 38.7469},
        'lagos': {'lat': 6.5244, 'lon': 3.3792},
        'accra': {'lat': 5.6037, 'lon': -0.1870},
        'johannesburg': {'lat': -26.2041, 'lon': 28.0473},
        'cape town': {'lat': -33.9249, 'lon': 18.4241},
        'harare': {'lat': -17.8252, 'lon': 31.0335},
        'lusaka': {'lat': -15.4167, 'lon': 28.2833},
        'maputo': {'lat': -25.9655, 'lon': 32.5832},
    }
    
    # Return matching locations
    matches = {k: v for k, v in locations.items() if query in k}
    
    return jsonify(matches)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
